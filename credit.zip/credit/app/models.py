from django.db import models
class name(models.Model):
    name=models.CharField(max_length=250)

    def __str__(self):
        return self.name
class detail(models.Model):
    det=models.ForeignKey(name,on_delete=models.CASCADE)
    name=models.CharField(max_length=250)
    accno=models.CharField(max_length=250)
    amt=models.IntegerField(default=0)


    def __str__(self):
        return self.name
